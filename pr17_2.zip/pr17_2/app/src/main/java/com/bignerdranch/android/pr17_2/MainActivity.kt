
package com.bignerdranch.android.pr17_2

import android.content.SharedPreferences
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import android.widget.EditText
import android.widget.TextView


class MainActivity : AppCompatActivity() {
    lateinit var login: EditText
    lateinit var pass: EditText
    lateinit var pref:SharedPreferences
    lateinit var text:TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        login=findViewById(R.id.login)
        pass=findViewById(R.id.login)
        text=findViewById(R.id.text)
    }

    fun save(view: View) {
        pref = getPreferences(MODE_PRIVATE)
        var ed= pref.edit()
        ed.putString("login", login.getText().toString())
        ed.putString("password", pass.getText().toString())
        ed.apply()
    }

    fun load(view: View) {
        pref = getPreferences(MODE_PRIVATE)
        text.setText(pref.getString("login", ""))
        text.setText(pref.getString("password", ""))

    }
}